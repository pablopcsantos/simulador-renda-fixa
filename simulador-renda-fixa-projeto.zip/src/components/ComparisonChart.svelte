<script lang="ts">
  import { formatCurrency } from '../lib/formatting';
  import type { ChartMode, InvestmentResult } from '../lib/types';

  export let resultados: InvestmentResult[];
  export let mode: ChartMode;

  const palette = ['#f59e0b', '#38bdf8', '#34d399', '#a78bfa', '#fb7185', '#60a5fa'];

  $: ordered = [...resultados].sort((a, b) => a.liquido - b.liquido);
  $: maxLiquid = Math.max(...ordered.map((r) => r.liquido), 1);
  $: maxHistory = Math.max(...resultados.flatMap((r) => r.historico), 1);
  $: maxPoints = Math.max(...resultados.map((r) => r.historico.length), 2);

  function linePoints(history: number[]): string {
    const left = 58;
    const top = 20;
    const width = 912;
    const height = 278;
    const divisor = Math.max(history.length - 1, 1);

    return history
      .map((value, index) => {
        const x = left + (index / divisor) * width;
        const y = top + height - (value / maxHistory) * height;
        return `${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(' ');
  }
</script>

<section class="panel chart-panel">
  <div class="chart-title">
    <div>
      <span class="eyebrow">COMPARAÇÃO</span>
      <h2>{mode === 'barras' ? 'Patrimônio final líquido' : 'Evolução do patrimônio líquido'}</h2>
    </div>
  </div>

  {#if mode === 'barras'}
    <div class="bars" aria-label="Gráfico de barras dos resultados">
      {#each ordered as r, index}
        <div class="bar-row">
          <div class="bar-label"><span>{r.nome}</span><b>{formatCurrency(r.liquido)}</b></div>
          <div class="bar-track">
            <div
              class="bar-fill"
              style={`width:${Math.max((r.liquido / maxLiquid) * 100, 1)}%;background:${palette[index % palette.length]}`}
            ></div>
          </div>
        </div>
      {/each}
    </div>
  {:else}
    <div class="line-chart-wrap">
      <svg class="line-chart" viewBox="0 0 1000 340" role="img" aria-label="Gráfico de linhas da evolução dos investimentos">
        <line x1="58" y1="298" x2="970" y2="298" class="axis" />
        <line x1="58" y1="20" x2="58" y2="298" class="axis" />
        <line x1="58" y1="159" x2="970" y2="159" class="grid" />
        <text x="54" y="316" class="axis-text">0</text>
        <text x="58" y="332" class="axis-text">0 mês</text>
        <text x="970" y="332" text-anchor="end" class="axis-text">{maxPoints - 1} meses</text>
        <text x="52" y="26" text-anchor="end" class="axis-text">{formatCurrency(maxHistory)}</text>

        {#each resultados as r, index}
          <polyline
            points={linePoints(r.historico)}
            fill="none"
            stroke={palette[index % palette.length]}
            stroke-width="4"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
        {/each}
      </svg>

      <div class="legend">
        {#each resultados as r, index}
          <span><i style={`background:${palette[index % palette.length]}`}></i>{r.nomeSimples}</span>
        {/each}
      </div>
    </div>
  {/if}
</section>
